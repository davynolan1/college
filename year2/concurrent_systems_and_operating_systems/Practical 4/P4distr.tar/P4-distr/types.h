typedef unsigned int   uint;
